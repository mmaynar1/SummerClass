public class TestPos
{
    public static void main( String[] args )
    {
        PointOfSaleSystem pointOfSaleSystem = new PointOfSaleSystem();
        pointOfSaleSystem.simulateRandomSales( );
    }
}