import java.math.BigDecimal;
import java.text.DecimalFormat;

public class TestAmortizationSchedule
{
    public static void main( String[] args )
    {
        TestAmortizationSchedule testAmortizationSchedule = new TestAmortizationSchedule();
        testAmortizationSchedule.test();
    }

    private void test()
    {
        int amountBorrowed = 135000;

        //Expressed as a percentage
        BigDecimal annualInterestRate = new BigDecimal( 7 );

        int termInYears = 1;

        AmortizationSchedule schedule = new AmortizationSchedule( amountBorrowed, annualInterestRate, termInYears );

        final int COLUMN_WIDTH = 20;
        if ( schedule.calculateSchedule() )
        {

            System.out.println( leftJustify( "Payment #", COLUMN_WIDTH ) +
                                leftJustify( "Monthly Payment", COLUMN_WIDTH ) +
                                leftJustify( "Interest", COLUMN_WIDTH ) +
                                leftJustify( "Principal", COLUMN_WIDTH ) +
                                leftJustify( "Total Interest", COLUMN_WIDTH ) +
                                leftJustify( "Total Principal", COLUMN_WIDTH ) +
                                leftJustify( "Balance", COLUMN_WIDTH ) );

            for (MonthlyPaymentDetail detail : schedule.getDetails())
            {
                System.out.println( leftJustify( (detail.getPaymentNumber()) + "", COLUMN_WIDTH ) +
                                    leftJustify( formatMoney( detail.getMonthlyPayment() ), COLUMN_WIDTH ) +
                                    leftJustify( formatMoney( detail.getInterest() ), COLUMN_WIDTH ) +
                                    leftJustify( formatMoney( detail.getPrincipal() ), COLUMN_WIDTH ) +
                                    leftJustify( formatMoney( detail.getTotalInterest() ), COLUMN_WIDTH ) +
                                    leftJustify( formatMoney( detail.getTotalPrincipal() ), COLUMN_WIDTH ) +
                                    leftJustify( formatMoney( detail.getBalance() ), COLUMN_WIDTH ) );
            }
        }
    }

    private String leftJustify( String value, int width )
    {
        return String.format( "%-" + width + "s", value );
    }

    public String formatMoney( BigDecimal money )
    {
        String formattedMoney;
        if ( money == null )
        {
            formattedMoney = "$0.00";
        }
        else
        {
            final DecimalFormat moneyFormat = new DecimalFormat( "$#,##0.00" );
            formattedMoney = moneyFormat.format( money );
        }

        return formattedMoney;
    }
}