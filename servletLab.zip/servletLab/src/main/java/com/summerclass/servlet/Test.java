package com.summerclass.servlet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class Test extends HttpServlet
{
    public void doPost( HttpServletRequest request, HttpServletResponse response ) throws ServletException, IOException
    {
        test( request, response );
    }

    public void doGet( HttpServletRequest request, HttpServletResponse response ) throws ServletException, IOException
    {
        test( request, response );
    }

    private void test( HttpServletRequest request, HttpServletResponse response ) throws IOException
    {
        response.setContentType( "text/html" );

        PrintWriter out = response.getWriter();
        out.println( "<html><body>This is it</body></html>" );

        out.close();
    }

}
