function Display()
{
   this.reset();
}

Display.prototype.getNumber = function (id)
{
   return parseInt(id);
};

Display.prototype.getOperator = function (id)
{
   var operator;
   switch (id)
   {
      case "addition":
         operator = "+";
         break;
      case "negative":
         operator = "-";
         break;
      case "multiplication":
         operator = "*";
         break;
      case "division":
         operator = "/";
         break;
      case "decimal":
         operator = ".";
         break;
      default:
         operator = "ERROR";
   }

   return operator;
};

Display.prototype.reset = function ()
{
   this.text = "";
   this.operatorPlaceable = false;
   this.decimalPlaceable = true;
};

Display.prototype.evaluate = function ()
{
   this.text = eval(this.text);
   this.display();
};

Display.prototype.addOperatorToDisplay = function (id)
{
   var operator = this.getOperator(id);

   if (this.operatorPlaceable)
   {
      this.addText(operator);
      this.operatorPlaceable = false;
      this.decimalPlaceable = true;
   }
};

Display.prototype.addNumberToDisplay = function (id)
{
   this.addText(id);
   this.operatorPlaceable = true;
};

Display.prototype.addText = function (text)
{
   this.text += text;
   this.display();
};

Display.prototype.clear = function ()
{
   this.reset();
   this.display();
};

Display.prototype.display = function ()
{
   document.getElementById("display").innerHTML = this.text;
};

Display.prototype.addNonRepeatableElement = function (id)
{
   var operator = this.getOperator(id);
   var length = this.text.length;
   var lastElement = this.text[length - 1];
   if (lastElement !== operator)
   {
      if (!(lastElement === "." && operator === "-"))
      {
         if (operator === ".")
         {
            if (this.decimalPlaceable)
            {
               this.addText(operator);
               this.decimalPlaceable = false;
            }
         }
         else
         {
            this.addText(operator);
            this.decimalPlaceable = true;
         }
      }
   }
};