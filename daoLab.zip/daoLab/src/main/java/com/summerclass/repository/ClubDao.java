package com.summerclass.repository;

public interface ClubDao
{
    String getClubId( int number );

    int getClubCount();
}
